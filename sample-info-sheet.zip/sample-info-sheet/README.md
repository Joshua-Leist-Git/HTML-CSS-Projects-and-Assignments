# Sample Info Sheet

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/PogRRbL](https://codepen.io/Josh-Nathaniel/pen/PogRRbL).

