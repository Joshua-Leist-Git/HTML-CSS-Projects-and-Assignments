# Structuring Page Content

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/RwdLmGg](https://codepen.io/Josh-Nathaniel/pen/RwdLmGg).

