# Sample CSS Text Styling

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/ZEZEbqJ](https://codepen.io/Josh-Nathaniel/pen/ZEZEbqJ).

