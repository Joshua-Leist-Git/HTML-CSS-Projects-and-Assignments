# Starbucks Homepage

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/mdggJbO](https://codepen.io/Josh-Nathaniel/pen/mdggJbO).

