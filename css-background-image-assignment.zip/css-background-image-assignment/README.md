# CSS Background Image Assignment

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/YzMepBv](https://codepen.io/Josh-Nathaniel/pen/YzMepBv).

