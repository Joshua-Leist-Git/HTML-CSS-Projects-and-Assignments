# CSS Gradients Practice

A Pen created on CodePen.

Original URL: [https://codepen.io/Josh-Nathaniel/pen/ZEZvmRr](https://codepen.io/Josh-Nathaniel/pen/ZEZvmRr).

